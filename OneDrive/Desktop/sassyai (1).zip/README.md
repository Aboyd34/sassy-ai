# SASSyAI Webhook

Webhook for Dialogflow fulfillment hosted on Azure App Service.

## Install Dependencies
```bash
npm install
```

## Run Locally
```bash
node index.js
```

## Endpoint
- POST `/webhook`
