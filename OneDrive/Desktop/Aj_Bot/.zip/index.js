require('dotenv').config();
const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());

app.post('/webhook', (req, res) => {
  const intent = req.body.queryResult?.intent?.displayName || 'Unknown';
  let response = '';

  switch (intent) {
    case 'GetHelp':
      response = "Oh honey, I got you. Here's what I can do: sass, facts, and action.";
      break;
    default:
      response = "I'm not feeling that vibe. Try asking differently, sugar.";
  }

  res.json({ fulfillmentText: response });
});

app.listen(port, () => {
  console.log(`Sassy AI is strutting on port ${port}`);
});